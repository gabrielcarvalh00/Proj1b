#include <stdio.h>

// Definição dos tipos de instrução
typedef enum {
    lit, opr, lod, sto, cal, inte, jmp, jpc
} fct;

// Definição da instrução
typedef struct {
    fct f;
    int l;
    int a;
} instruction;

// Definição do tamanho máximo da pilha
#define stacksize 500

// Definição das variáveis globais
int p = 0, b = 1, t = 0;
instruction code[100];

// Pilha de execução
int s[stacksize];

// Função para encontrar a base l levels down
int base(int l) {
    int b1 = b;
    while (l > 0) {
        b1 = s[b1];
        l--;
    }
    return b1;
}

// Função principal para interpretar o código
void interpret() {
    printf("start pl/0\n");
    t = 0;
    b = 1;
    p = 0;
    s[1] = 0;
    s[2] = 0;
    s[3] = 0;
    do {
        instruction i = code[p++];
        switch (i.f) {
            case lit:
                s[++t] = i.a;
                printf("lit %d\n", i.a);
                break;
            case opr:
                switch (i.a) {
                    case 0: // return
                        t = b - 1;
                        p = s[t + 3];
                        b = s[t + 2];
                        break;
                    case 1: // negation
                        s[t] = -s[t];
                        break;
                    case 2: // addition
                        t--;
                        s[t] += s[t + 1];
                        break;
                    // outras operações aritméticas aqui
                }
                break;
            // outras instruções aqui
        }
    } while (p != 0);
    printf("end pl/0\n");
}

// Função principal
int main() {
    // Aqui você deve inicializar o array code com as instruções desejadas
    interpret();
    return 0;
}
