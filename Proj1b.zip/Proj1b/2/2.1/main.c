#include <stdio.h>

// Definição dos tipos de instrução
typedef enum {
    lit, opr, lod, sto, cal, inte, jmp, jpc
} fct;

// Definição da instrução
typedef struct {
    fct f;
    int l;
    int a;
} instruction;

// Definição do tamanho máximo da pilha
#define stacksize 500

// Definição das variáveis globais
int p = 0, b = 1, t = 0;
instruction code[100];

// Pilha de execução
int s[stacksize];

// Função para encontrar a base l levels down
int base(int l) {
    int b1 = b;
    while (l > 0) {
        b1 = s[b1];
        l--;
    }
    return b1;
}

// Função principal para interpretar o código
void interpret() {
    printf("start pl/0\n");
    t = 0;
    b = 1;
    p = 0;
    s[1] = 0;
    s[2] = 0;
    s[3] = 0;
    do {
        instruction i = code[p++];
        switch (i.f) {
            case lit:
                s[++t] = i.a;
                printf("lit %d\n", i.a);
                break;
            case opr:
                switch (i.a) {
                    case 0: // return
                        t = b - 1;
                        p = s[t + 3];
                        b = s[t + 2];
                        break;
                    case 2: // addition
                        t--;
                        s[t] += s[t + 1];
                        break;
                }
                break;
            case sto:
                s[i.a] = s[t--];
                printf("sto %d\n", i.a);
                break;
        }
    } while (p != 0);
    printf("end pl/0\n");
}

// Função principal
int main() {
    // Inicialização do array 'code' com as instruções desejadas para calcular a soma de 1 até 10
    code[0].f = lit;
    code[0].a = 0; // carrega 0 (inicializa o acumulador)
    code[1].f = sto;
    code[1].a = 0; // armazena o valor inicial no endereço 0
    code[2].f = lit;
    code[2].a = 1; // carrega 1
    code[3].f = sto;
    code[3].a = 1; // armazena 1 no endereço 1
    code[4].f = lit;
    code[4].a = 10; // carrega 10
    code[5].f = sto;
    code[5].a = 2; // armazena 10 no endereço 2
    code[6].f = lit;
    code[6].a = 0; // carrega 0
    code[7].f = sto;
    code[7].a = 3; // armazena 0 no endereço 3 (contador)
    code[8].f = lit;
    code[8].a = 0; // carrega 0
    code[9].f = sto;
    code[9].a = 4; // armazena 0 no endereço 4 (soma)
    code[10].f = lod;
    code[10].a = 3; // carrega o contador
    code[11].f = lit;
    code[11].a = 10; // carrega 10
    code[12].f = opr;
    code[12].a = 11; // verifica se o contador chegou a 10
    code[13].f = jpc;
    code[13].a = 22; // se não, salta para a instrução 22
    code[14].f = lod;
    code[14].a = 4; // carrega a soma
    code[15].f = lod;
    code[15].a = 1; // carrega o próximo número
    code[16].f = opr;
    code[16].a = 2; // soma com o acumulador
    code[17].f = sto;
    code[17].a = 4; // armazena o resultado da soma
    code[18].f = lod;
    code[18].a = 3; // carrega o contador
    code[19].f = lit;
    code[19].a = 1; // carrega 1
    code[20].f = opr;
    code[20].a = 2; // incrementa o contador
    code[21].f = sto;
    code[21].a = 3; // armazena o contador
    code[22].f = lod;
    code[22].a = 3; // carrega o contador
    code[23].f = lit;
    code[23].a = 10; // carrega 10
    code[24].f = opr;
    code[24].a = 10; // verifica se o contador chegou a 10
    code[25].f = jpc;
    code[25].a = 14; // se não, salta para a instrução
    code[26].f = lit;
    code[26].a = 4; // carrega a soma
    code[27].f = opr;
    code[27].a = 2; // imprime a soma
    code[28].f = opr;
    code[28].a = 0; // retorna
    code[29].f = opr;
    code[29].a = 0; // finaliza o programa

    interpret();
    return 0;
}
