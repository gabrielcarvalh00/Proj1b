#include <stdio.h>

// Definição dos tipos de instrução
typedef enum {
    lit, opr, lod, sto, cal, inte, jmp, jpc
} fct;

// Definição da instrução
typedef struct {
    fct f;
    int l;
    int a;
} instruction;

// Função para calcular a soma dos quadrados dos números de 1 a n
int sumOfSquares(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += i * i;
    }
    return sum;
}

// Função para gerar o código p-code
void generatePCode(instruction code[], int n) {
    int addr = 0;
    for (int i = 1; i <= n; i++) {
        code[addr].f = lit;
        code[addr].a = i;
        addr++;
    }
}

// Função principal para interpretar o código
void interpret() {
    FILE *output_file = fopen("output.txt", "w"); // Abrindo o arquivo de saída
    int sum = sumOfSquares(100); // Calculando a soma dos quadrados de 1 a 100
    fprintf(output_file, "Resultado: %d\n", sum); // Escrevendo o resultado na primeira linha

    // Gerando o código p-code
    instruction code[100];
    generatePCode(code, 100);

    // Escrevendo as instruções no arquivo de saída
    fprintf(output_file, "start pl/0\n");
    for (int i = 0; i < 100; i++) {
        fprintf(output_file, "lit %d\n", code[i].a); // Escrevendo as instruções 'lit' para os números de 1 a 100
    }
    fprintf(output_file, "end pl/0\n");

    fclose(output_file); // Fechando o arquivo de saída
}

// Função principal
int main() {
    interpret();
    return 0;
}
